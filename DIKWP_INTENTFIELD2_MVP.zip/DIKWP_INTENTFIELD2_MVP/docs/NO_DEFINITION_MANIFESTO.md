# No-Definition Manifesto

1. A word is an entry handle, not the object of inquiry.
2. A concept boundary may be useful for a task, but it must remain indexed by observer, context, scale, time and intent.
3. No output may claim that a single sentence captures an observer-free essence.
4. DIKWP resources are co-equal and mutually revisable.
5. Intent is plural, time-varying and revisable by D, I, K, W and P.
6. Semantic analysis must survive concept-label masking and relabeling.
7. Disagreement, obstruction and untranslatable residue are first-class outputs.
8. New semantic coordinates remain unnamed until independent tests show that they discriminate real routes.
9. A problem kernel is the smallest set of relations that matters for a declared transformation; it is not a universal ontology.
10. The system must end in better questions, discriminating actions and explicit residuals—not in authority disguised as definition.
