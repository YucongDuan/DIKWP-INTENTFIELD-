# Formal model

## 1. Definition-free inquiry bundle

An inquiry bundle is:

`Q = <R, T, Φ, O, B, Π>`

- `R`: provenance-carrying semantic traces;
- `T`: context-indexed DIKWP×DIKWP transformations;
- `Φ`: one or more revisable intent fields;
- `O`: observer positions;
- `B`: provisional boundaries and scales;
- `Π`: provenance and authorization relations.

There is no required concept or ontology-root field.

## 2. Mixed DIKWP traces

Each trace has a mixed type vector:

`μ(r) ∈ Δ⁴`

D, I, K, W and P are co-equal semantic resource modes. A trace may simultaneously carry observation, relation, explanatory, value and purpose mass.

## 3. Transformation tensor

A transformation is indexed by:

`𝒯[x,y,o,c,t,m,s,π,φ]`

where `x,y ∈ {D,I,K,W,P}`, and the remaining indices represent observer, context, time, modality, scale, provenance and active intent field. The same primitive pair can have different semantics under different indices.

## 4. Intent field

An intent field is not a terminal P node. It is a revisable vector field over traces and transformations:

`Φ_i(r,e,t) = <advance, preserve, block, uncertainty, power, reversibility>`

A transformation into P may revise the field, and P may transform into every other DIKWP resource. Multiple intent fields may coexist and conflict.

## 5. Semantic trajectories

A trajectory is a composable path:

`τ = r₀ --T₁--> r₁ --T₂--> ... --Tₙ--> rₙ`

Trajectories may contain cycles and self-transformations. They are compared through a Pareto vector rather than a scalar truth score:

`v(τ) = <evidence floor, intent advance, reversibility, observer diversity, residual preservation, transformation diversity, power symmetry, uncertainty fit>`

## 6. Concept erasure

Given anchor terms `A`, an erasure operator `M_A` masks their surface occurrence while preserving trace identity, relations, provenance and intent links. If:

`Kernel(Q) ≈ Kernel(M_A(Q))`

and

`Routes(Q) ≈ Routes(M_A(Q))`,

the inquiry is less dependent on concept labels. This is an engineering audit, not proof of metaphysical objectivity.

## 7. Problem kernel

For intent `Φ_i`, the problem kernel is a compact set of transformation relations with high route coverage, counterfactual reachability impact or explicit obstruction/preservation/revision effects:

`K_i = K_obstruction ∪ K_preservation ∪ K_discrimination ∪ K_revision`

`K_i` is always intent-indexed. It must never be reported as the definition of the surface term.

## 8. Residual coordinate

A residual cluster that cannot be represented by existing routes becomes an opaque candidate coordinate `UAX-n`. It receives discriminating tests, promotion conditions and rollback conditions. No semantic name is installed automatically.
