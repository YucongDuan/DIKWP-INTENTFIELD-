# Integration with the Yucong Duan DIKWP ecosystem

## MESH²

Use MESH² as the low-level semantic graph and transformation library. INTENTFIELD² changes the inquiry entry point from `concept` to a definition-free intent bundle and adds erasure, Pareto trajectory, problem-kernel and unnamed-residual protocols.

## NEXUS FORGE

Run INTENTFIELD² before repository/module composition. The problem kernel determines which capabilities are needed; surface keywords must not directly choose repositories.

## SemanticJustice

Replace concept-first case registries with observer traces, lawful intent fields, affected-party preservation conditions and issue kernels. Legal terms remain useful interfaces but must not determine the evidence path by themselves.

## TRIZ SemanticForge

Replace “Concept problem statement” as the mandatory first stage with intent fields, relational traces and concept erasure. TRIZ principles are candidate operators after a problem kernel is obtained, not a preinstalled explanation of the problem.

## AION / CREDENCE / PRAXIS / MANDATE

- AION turns unresolved kernel relations into forecast questions.
- CREDENCE independently tests transformation and kernel claims.
- PRAXIS compiles verified action hypotheses into reversible pilots.
- MANDATE supplies local authorization, rights, appeal and sunset.
