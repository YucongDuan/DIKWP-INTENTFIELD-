# Changelog

## 0.1.0 - 2026-07-18

- Definition-free inquiry bundle with no required `concept` field.
- Complete 25-class DIKWP×DIKWP registry.
- Revisable multi-intent fields.
- Pareto trajectory exploration.
- Concept erasure and adversarial anti-definition audit.
- Intent-indexed problem-kernel mining.
- Opaque UAX residual coordinates with tests and rollback.
- Offline dashboard, figures, schemas, and 13 automated tests.
