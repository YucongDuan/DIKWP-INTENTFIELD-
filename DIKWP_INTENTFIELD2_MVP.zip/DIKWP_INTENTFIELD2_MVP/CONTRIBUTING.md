# Contributing

DIKWP-INTENTFIELD² accepts contributions that preserve the definition-free contract.

Every pull request that changes schemas, routing, residual discovery, intent handling, or output semantics must include:

1. a statement of the intended change and affected parties;
2. a concept-erasure or adversarial-renaming test;
3. evidence that Purpose remains bidirectional and revisable;
4. a counterexample or rollback condition;
5. deterministic tests and a provenance note.

A contribution must not introduce a mandatory concept registry, a final-definition output, a scalar truth score, an unchallengeable Purpose controller, or an automatically named semantic axis.
