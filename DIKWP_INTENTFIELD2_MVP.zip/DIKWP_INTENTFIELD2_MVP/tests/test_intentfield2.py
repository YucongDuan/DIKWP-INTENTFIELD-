from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator

from dikwp_intentfield2.analysis import IntentFieldAnalyzer
from dikwp_intentfield2.audit import NoDefinitionAudit
from dikwp_intentfield2.erasure import ConceptErasureEngine
from dikwp_intentfield2.io import load_bundle
from dikwp_intentfield2.mesh import IntentSemanticMesh
from dikwp_intentfield2.transforms import TransformRegistry

ROOT = Path(__file__).resolve().parents[1]
EXAMPLE = ROOT / "examples" / "era_of_experience_intent_bundle.json"
BAD = ROOT / "examples" / "hierarchical_anti_example.json"
SCHEMA = ROOT / "schemas" / "intent_field_bundle.schema.json"


class IntentFieldTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.bundle = load_bundle(EXAMPLE)
        cls.result = IntentFieldAnalyzer(cls.bundle).analyze(max_depth=6, run_erasure=True)

    def test_01_schema_has_no_concept_requirement(self):
        schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
        self.assertNotIn("concept", schema.get("required", []))
        validator = Draft202012Validator(schema)
        raw = json.loads(EXAMPLE.read_text(encoding="utf-8"))
        errors = list(validator.iter_errors(raw))
        self.assertEqual(errors, [])

    def test_02_all_25_transforms_are_registered_and_used(self):
        registry = TransformRegistry()
        self.assertEqual(len(registry.all()), 25)
        coverage = registry.coverage([e.transform_type for e in self.bundle.transformations])
        self.assertEqual(coverage["coverage"], 1.0)
        self.assertEqual(coverage["missing"], [])

    def test_03_purpose_is_bidirectional_and_revisable(self):
        types = [e.transform_type for e in self.bundle.transformations]
        self.assertTrue(any(t.endswith("->P") for t in types))
        self.assertTrue(any(t.startswith("P->") for t in types))
        self.assertTrue(self.result["intent_revisions"])

    def test_04_concept_erasure_preserves_kernel_and_routes(self):
        audit = self.result["concept_erasure_audit"]
        self.assertTrue(audit["passed"])
        self.assertGreaterEqual(audit["kernel_jaccard"], 0.95)
        self.assertGreaterEqual(audit["trajectory_jaccard"], 0.95)

    def test_05_residual_axes_are_unnamed(self):
        self.assertTrue(self.result["residual_axes"])
        for axis in self.result["residual_axes"]:
            self.assertIsNone(axis["provisional_name"])
            self.assertTrue(axis["axis_id"].startswith("UAX-"))
            self.assertTrue(axis["discriminating_tests"])

    def test_06_problem_kernel_is_intent_indexed_and_provenanced(self):
        self.assertTrue(self.result["problem_kernel"])
        for item in self.result["problem_kernel"]:
            self.assertIn(item["intent_id"], {"INT-RIGHTS", "INT-SPEED"})
            self.assertTrue(item["provenance"])
            self.assertNotIn("definition", item)

    def test_07_different_intents_can_produce_different_kernels(self):
        rights = {(x["relation_id"], x["kernel_role"]) for x in self.result["problem_kernel"] if x["intent_id"] == "INT-RIGHTS"}
        speed = {(x["relation_id"], x["kernel_role"]) for x in self.result["problem_kernel"] if x["intent_id"] == "INT-SPEED"}
        self.assertNotEqual(rights, speed)
        self.assertTrue(self.result["intent_comparison"]["intent_sensitive_relations"])

    def test_08_no_scalar_truth_score_or_final_label(self):
        text = json.dumps(self.result, ensure_ascii=False)
        self.assertNotIn("truth_score", text)
        self.assertNotIn("essence_score", text)
        self.assertNotIn("final_label", text)
        self.assertEqual(self.result["output_contract"], "intent-indexed semantic navigation; no concept definition or final categorical label")

    def test_09_good_bundle_passes_no_definition_audit(self):
        self.assertEqual(self.result["no_definition_audit"]["status"], "PASS")

    def test_10_hierarchical_anti_example_is_rejected_or_reviewed(self):
        bad_bundle = load_bundle(BAD)
        mesh = IntentSemanticMesh(bad_bundle)
        audit = NoDefinitionAudit(mesh).run()
        self.assertIn(audit["status"], {"REVIEW", "FAIL"})
        codes = {x["code"] for x in audit["issues"]}
        self.assertIn("INCOMPLETE_DIKWP_X_DIKWP_COVERAGE", codes)
        self.assertIn("PURPOSE_NOT_MUTUALLY_REVISABLE", codes)
        self.assertIn("OBSERVER_COLLAPSE", codes)

    def test_11_deterministic_analysis(self):
        result2 = IntentFieldAnalyzer(load_bundle(EXAMPLE)).analyze(max_depth=6, run_erasure=True)
        k1 = [(x["intent_id"], x["relation_id"], x["kernel_role"]) for x in self.result["problem_kernel"]]
        k2 = [(x["intent_id"], x["relation_id"], x["kernel_role"]) for x in result2["problem_kernel"]]
        self.assertEqual(k1, k2)
        p1 = [(x["intent_id"], x["transform_path"]) for x in self.result["pareto_trajectories"]]
        p2 = [(x["intent_id"], x["transform_path"]) for x in result2["pareto_trajectories"]]
        self.assertEqual(p1, p2)

    def test_12_no_hard_coded_named_axis_catalog(self):
        residual_source = (ROOT / "src" / "dikwp_intentfield2" / "residuals.py").read_text(encoding="utf-8")
        self.assertNotIn("DIMENSION_CATALOG", residual_source)
        self.assertNotIn("candidate_dimension_en", residual_source)

    def test_13_action_hypotheses_prohibit_universal_definition(self):
        self.assertTrue(self.result["action_hypotheses"])
        for action in self.result["action_hypotheses"]:
            self.assertTrue(action["prohibited_result"])
            self.assertTrue(action["pre_action_prediction_required"])
            self.assertTrue(action["counterfactual_required"])


if __name__ == "__main__":
    unittest.main()
