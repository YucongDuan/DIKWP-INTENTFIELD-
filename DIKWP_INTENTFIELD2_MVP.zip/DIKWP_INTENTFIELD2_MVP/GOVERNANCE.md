# Governance

This reference package is designed for federated stewardship.

- Protocol maintainers review schemas and compatibility.
- No-definition auditors review concept dependence and hierarchy leakage.
- Affected-party reviewers inspect intent, power, reversibility, and exclusions.
- Independent replicators validate erasure stability and problem-kernel reproduction.

No single role should control the schema, benchmark, release decision, and settlement of its own claims. Forks that demonstrate stronger evidence or better preservation of residuals may supersede the reference implementation.
