# Security policy

This prototype is offline-first and does not execute real-world actions. Report vulnerabilities concerning unsafe deserialization, path traversal, provenance tampering, audit bypass, or generated HTML injection through a private security channel before public disclosure.

Do not submit personal, medical, legal, or confidential organizational data to the included synthetic demonstration.
