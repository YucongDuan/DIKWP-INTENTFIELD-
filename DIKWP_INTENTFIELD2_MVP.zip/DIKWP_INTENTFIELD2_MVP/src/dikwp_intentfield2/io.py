from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from .models import DIKWPType, InquiryBundle, IntentPulse, SemanticTrace, TransformEvent


def load_bundle(path: str | Path) -> InquiryBundle:
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    forbidden = {"concept", "definition", "concept_registry", "final_label"}
    if forbidden & set(raw):
        raise ValueError(f"Definition-locked top-level fields are prohibited: {sorted(forbidden & set(raw))}")
    intents = [IntentPulse(**item) for item in raw.get("intents", [])]
    traces = [SemanticTrace(**item) for item in raw.get("traces", [])]
    transformations = []
    for item in raw.get("transformations", []):
        data = dict(item)
        data["source_type"] = DIKWPType(data["source_type"])
        data["target_type"] = DIKWPType(data["target_type"])
        transformations.append(TransformEvent(**data))
    bundle = InquiryBundle(
        inquiry_id=raw["inquiry_id"],
        surface_prompt=raw.get("surface_prompt", ""),
        anchor_terms=list(raw.get("anchor_terms", [])),
        intents=intents,
        traces=traces,
        transformations=transformations,
        observers=list(raw.get("observers", [])),
        boundaries=list(raw.get("boundaries", [])),
        metadata=dict(raw.get("metadata", {})),
    )
    bundle.validate()
    return bundle


def dump_json(path: str | Path, data: Any) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
