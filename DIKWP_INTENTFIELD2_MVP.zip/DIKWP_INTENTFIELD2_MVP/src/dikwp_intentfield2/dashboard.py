from __future__ import annotations

import html
from pathlib import Path
from typing import Any, Dict, Mapping, Sequence


CSS = """
:root { --ink:#0f172a; --muted:#475569; --line:#cbd5e1; --panel:#f8fafc; --accent:#0f766e; }
* { box-sizing:border-box; }
body { margin:0; font-family: system-ui, -apple-system, 'Noto Sans CJK SC', sans-serif; color:var(--ink); background:#eef2f7; }
header { background:linear-gradient(125deg,#0f172a,#0f766e); color:white; padding:34px 6vw; }
header h1 { margin:0 0 8px; font-size:32px; }
header p { margin:0; max-width:980px; opacity:.9; }
main { max-width:1200px; margin:0 auto; padding:28px 20px 60px; }
.card { background:white; border:1px solid var(--line); border-radius:14px; padding:20px; margin:16px 0; box-shadow:0 5px 22px rgba(15,23,42,.05); }
.grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(240px,1fr)); gap:14px; }
.metric { background:var(--panel); border-radius:10px; padding:14px; }
.metric b { font-size:25px; display:block; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th,td { border-bottom:1px solid #e2e8f0; padding:9px 8px; text-align:left; vertical-align:top; }
th { background:#f1f5f9; position:sticky; top:0; }
code { background:#f1f5f9; padding:2px 5px; border-radius:4px; }
.badge { display:inline-block; border-radius:999px; padding:3px 9px; background:#dbeafe; margin:2px; font-size:12px; }
.pass { color:#166534; font-weight:700; }
.fail { color:#b91c1c; font-weight:700; }
img { max-width:100%; border:1px solid #e2e8f0; border-radius:10px; }
small { color:var(--muted); }
"""


def _table(headers: Sequence[str], rows: Sequence[Sequence[Any]]) -> str:
    out = ["<div style='overflow:auto'><table><thead><tr>"]
    out += [f"<th>{html.escape(str(h))}</th>" for h in headers]
    out.append("</tr></thead><tbody>")
    for row in rows:
        out.append("<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in row) + "</tr>")
    out.append("</tbody></table></div>")
    return "".join(out)


def render_dashboard(result: Mapping[str, Any], out_path: str | Path, figures: Mapping[str, str] | None = None) -> None:
    figures = figures or {}
    erasure = result.get("concept_erasure_audit", {})
    audit = result.get("no_definition_audit", {})
    kernel = result.get("problem_kernel", [])
    trajectories = result.get("pareto_trajectories", [])
    residuals = result.get("residual_axes", [])
    experiments = result.get("action_hypotheses", [])
    body = [
        "<!doctype html><html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>",
        f"<style>{CSS}</style><title>DIKWP-INTENTFIELD²</title></head><body>",
        "<header><h1>DIKWP-INTENTFIELD²</h1>",
        f"<p>{html.escape(str(result.get('surface_prompt','')))}</p></header><main>",
        "<section class='card'><h2>运行摘要</h2><div class='grid'>",
        f"<div class='metric'><small>意图数</small><b>{len(result.get('intents',[]))}</b></div>",
        f"<div class='metric'><small>Pareto路径</small><b>{len(trajectories)}</b></div>",
        f"<div class='metric'><small>问题核关系</small><b>{len(kernel)}</b></div>",
        f"<div class='metric'><small>未命名残差坐标</small><b>{len(residuals)}</b></div>",
        f"<div class='metric'><small>25类变换覆盖</small><b>{result.get('transformation_coverage',{}).get('coverage',0):.0%}</b></div>",
        f"<div class='metric'><small>无定义审计</small><b class='{'pass' if audit.get('status')=='PASS' else 'fail'}'>{html.escape(str(audit.get('status')))}</b></div>",
        "</div></section>",
    ]
    if figures:
        body.append("<section class='card'><h2>核心图</h2><div class='grid'>")
        for title, rel in figures.items():
            body.append(f"<figure><img src='{html.escape(rel)}' alt='{html.escape(title)}'><figcaption>{html.escape(title)}</figcaption></figure>")
        body.append("</div></section>")

    body.append("<section class='card'><h2>概念词遮蔽审计</h2>")
    status = "通过" if erasure.get("passed") else "未通过"
    body.append(f"<p class='{'pass' if erasure.get('passed') else 'fail'}'>{status}</p>")
    body.append(_table(["指标","数值"], [["问题核Jaccard", erasure.get("kernel_jaccard")], ["路径Jaccard", erasure.get("trajectory_jaccard")], ["说明", erasure.get("interpretation")]]))
    body.append("</section>")

    body.append("<section class='card'><h2>意图索引问题核</h2>")
    body.append(_table(["意图","角色","关系ID","变换","关系说明","反事实影响","来源"], [
        [x.get("intent_id"),x.get("kernel_role"),x.get("relation_id"),x.get("transform_type"),x.get("relation_text"),x.get("counterfactual_reachability_impact"),x.get("provenance")]
        for x in kernel
    ]))
    body.append("</section>")

    body.append("<section class='card'><h2>Pareto语义路径</h2>")
    body.append(_table(["意图","路径ID","轨迹","变换","证据","推进","可逆","观察者多样性","是否修订意图"], [
        [x.get("intent_id"),x.get("id")," → ".join(x.get("trace_path",[]))," / ".join(x.get("transform_path",[])),x.get("vector",{}).get("evidence_floor"),x.get("vector",{}).get("intent_advance"),x.get("vector",{}).get("reversibility_floor"),x.get("vector",{}).get("observer_diversity"),x.get("revises_intent")]
        for x in trajectories
    ]))
    body.append("</section>")

    body.append("<section class='card'><h2>未命名残差坐标</h2>")
    body.append(_table(["坐标ID","状态","来源事件","观察者","测试数","规则"], [
        [x.get("axis_id"),x.get("status"),", ".join(x.get("source_events",[])),", ".join(x.get("observers",[])),len(x.get("discriminating_tests",[])),x.get("promotion_rule")]
        for x in residuals
    ]))
    body.append("</section>")

    body.append("<section class='card'><h2>行动假设</h2>")
    body.append(_table(["实验ID","意图","目标","类型","问题","可逆性","禁止结论"], [
        [x.get("experiment_id"),x.get("intent_id"),x.get("target_relation"),x.get("action_kind"),x.get("question"),x.get("reversibility"),x.get("prohibited_result")]
        for x in experiments
    ]))
    body.append("</section>")

    body.append("<section class='card'><h2>边界</h2><p>本仪表盘不输出任何概念的最终定义、形而上本质或自动决策。它只呈现特定意图、观察者、证据和变换路径下的问题核、残差与可检验行动。</p></section>")
    body.append("</main></body></html>")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text("".join(body), encoding="utf-8")
