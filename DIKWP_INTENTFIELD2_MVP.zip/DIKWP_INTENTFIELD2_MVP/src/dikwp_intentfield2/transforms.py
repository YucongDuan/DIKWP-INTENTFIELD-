from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Mapping, Tuple

from .models import DIKWPType


@dataclass(frozen=True, slots=True)
class PrimitiveTransform:
    source: DIKWPType
    target: DIKWPType
    inquiry_move: str
    anti_definition_guard: str

    @property
    def id(self) -> str:
        return f"{self.source.value}->{self.target.value}"

    def to_dict(self) -> Dict[str, str]:
        data = asdict(self)
        data["source"] = self.source.value
        data["target"] = self.target.value
        data["id"] = self.id
        return data


# These are inquiry moves, not content definitions. They describe what kind of
# semantic change a transformation attempts, while leaving the domain content open.
_MOVE = {
    "D->D": ("re-observe, calibrate, segment or compare traces", "do not rename a measurement as an essence"),
    "D->I": ("surface a difference, dependency or context-sensitive relation", "do not treat correlation as a settled relation"),
    "D->K": ("propose a falsifiable explanatory relation", "do not upgrade a trace directly into truth"),
    "D->W": ("expose stakes, burdens, irreversible consequences or protected interests", "do not infer value solely from frequency"),
    "D->P": ("revise or generate an intent pulse from observed consequences", "do not make observed behavior the only legitimate purpose"),
    "I->D": ("request discriminating observations for an unresolved relation", "do not manufacture data to fit the relation"),
    "I->I": ("re-segment, contrast, compose or decompose relations", "do not freeze a relation into a category"),
    "I->K": ("construct competing causal or predictive accounts", "do not suppress alternatives"),
    "I->W": ("reveal who benefits, who bears cost and which scales are omitted", "do not collapse plurality into one utility"),
    "I->P": ("generate or split intents when a relation changes what matters", "do not assume one observer owns the agenda"),
    "K->D": ("derive observations that would distinguish models", "do not count restated assumptions as evidence"),
    "K->I": ("reinterpret relations under a model and expose model dependence", "do not erase the pre-model trace"),
    "K->K": ("compare, revise, merge or reject explanatory structures", "do not make coherence a substitute for contact with the world"),
    "K->W": ("project long-term or cross-scale consequences of a model", "do not hide normative choices inside prediction"),
    "K->P": ("revise action direction because understanding changed", "do not treat knowledge as automatic authority"),
    "W->D": ("demand observations needed to protect affected parties", "do not surveil merely because a value is invoked"),
    "W->I": ("distinguish legitimate from harmful or exclusionary relations", "do not universalize one party's value grammar"),
    "W->K": ("require models capable of representing value conflict and externalities", "do not convert moral concern into an untestable claim"),
    "W->W": ("surface conflicts among values, timescales and affected groups", "do not average away vetoes or irreversible harms"),
    "W->P": ("constrain, suspend, split or redirect an intent", "do not make wisdom a hidden supreme controller"),
    "P->D": ("select observations relevant to a declared transformation", "do not make unobserved phenomena nonexistent"),
    "P->I": ("select differences that matter for the current intent", "do not confuse relevance with ontology"),
    "P->K": ("ask what must be known before acting", "do not demand certainty impossible for the decision"),
    "P->W": ("expose beneficiaries, burdens and protected invariants of an intent", "do not present preference as neutral analysis"),
    "P->P": ("revise, fork, merge, defer or withdraw intents", "do not preserve an intent merely because it came first"),
}


class TransformRegistry:
    def __init__(self) -> None:
        self._items: Dict[str, PrimitiveTransform] = {}
        for src in DIKWPType.ordered():
            for dst in DIKWPType.ordered():
                key = f"{src.value}->{dst.value}"
                move, guard = _MOVE[key]
                self._items[key] = PrimitiveTransform(src, dst, move, guard)

    def get(self, key: str) -> PrimitiveTransform:
        return self._items[key]

    def all(self) -> List[PrimitiveTransform]:
        return [self._items[k] for k in DIKWPType.pairs()]

    def coverage(self, used: Iterable[str]) -> Dict[str, object]:
        used_set = set(used)
        all_set = set(self._items)
        return {
            "used": sorted(used_set & all_set),
            "missing": sorted(all_set - used_set),
            "coverage": round(len(used_set & all_set) / len(all_set), 6),
        }
