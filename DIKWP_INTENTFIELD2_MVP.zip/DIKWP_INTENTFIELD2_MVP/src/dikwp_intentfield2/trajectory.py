from __future__ import annotations

import hashlib
from collections import Counter
from math import isfinite
from typing import Dict, Iterable, List, Mapping, Sequence, Set, Tuple

import networkx as nx

from .mesh import IntentSemanticMesh
from .models import IntentPulse, SemanticTrajectory, TrajectoryVector, TransformEvent


def _stable_id(parts: Sequence[str]) -> str:
    digest = hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()[:12]
    return f"TRJ-{digest}"


def _path_vectors(mesh: IntentSemanticMesh, intent: IntentPulse, nodes: List[str], edges: List[str]) -> TrajectoryVector:
    events = [mesh.events[eid] for eid in edges]
    effects = [event.effect_for(intent.id) for event in events]
    if events:
        evidence_floor = min(event.confidence * min(mesh.traces[event.source].reliability, mesh.traces[event.target].reliability) for event in events)
        reversibility_floor = min(event.reversibility for event in events)
        observers = {event.observer for event in events} | {mesh.traces[n].observer for n in nodes}
        observer_diversity = len(observers) / max(1, len(mesh.observers()))
        transform_diversity = len({event.transform_type for event in events}) / len(events)
        residual_preservation = 1.0 - sum(1 for eff in effects if eff["suppresses_residual"]) / len(effects)
        power_symmetry = 1.0 - sum(float(eff["power_asymmetry"]) for eff in effects) / len(effects)
        advance_raw = sum(float(eff["advance"]) - float(eff["block"]) for eff in effects)
        intent_advance = max(0.0, min(1.0, 0.5 + advance_raw / (2.0 * len(effects))))
        mean_uncertainty = sum(float(eff["uncertainty"]) for eff in effects) / len(effects)
        uncertainty_fit = 1.0 - abs(mean_uncertainty - intent.uncertainty_tolerance)
    else:
        evidence_floor = 0.0
        reversibility_floor = 0.0
        observer_diversity = 0.0
        transform_diversity = 0.0
        residual_preservation = 1.0
        power_symmetry = 1.0
        intent_advance = 0.0
        uncertainty_fit = 0.0
    return TrajectoryVector(
        evidence_floor=evidence_floor,
        intent_advance=intent_advance,
        reversibility_floor=reversibility_floor,
        observer_diversity=observer_diversity,
        residual_preservation=residual_preservation,
        transformation_diversity=transform_diversity,
        power_symmetry=power_symmetry,
        uncertainty_fit=uncertainty_fit,
    )


class TrajectoryExplorer:
    """Enumerates non-hierarchical semantic routes and returns a Pareto set.

    It does not collapse route quality into a single score. A route is kept when
    no other route is at least as good on every declared dimension and strictly
    better on one.
    """

    def __init__(self, mesh: IntentSemanticMesh) -> None:
        self.mesh = mesh

    def enumerate(self, intent_id: str, max_depth: int = 6, max_paths: int = 600) -> List[SemanticTrajectory]:
        intent = self.mesh.intents[intent_id]
        g = self.mesh.intent_subgraph(intent_id)
        raw: List[SemanticTrajectory] = []
        seen_paths: Set[Tuple[str, ...]] = set()
        for start in intent.start_traces:
            for goal in intent.goal_traces:
                if start == goal:
                    continue
                try:
                    node_paths = nx.all_simple_paths(nx.DiGraph(g), start, goal, cutoff=max_depth)
                except nx.NetworkXNoPath:
                    continue
                for node_path in node_paths:
                    if len(raw) >= max_paths:
                        break
                    signature = tuple(node_path)
                    if signature in seen_paths:
                        continue
                    seen_paths.add(signature)
                    # Choose the best available parallel edge for evidence and reversibility
                    edge_ids: List[str] = []
                    for u, v in zip(node_path, node_path[1:]):
                        candidates = []
                        for key, data in g[u][v].items():
                            event: TransformEvent = data["event"]
                            effect = event.effect_for(intent_id)
                            candidates.append((
                                event.confidence,
                                event.reversibility,
                                float(effect["advance"]) - float(effect["block"]),
                                key,
                            ))
                        candidates.sort(reverse=True)
                        edge_ids.append(candidates[0][-1])
                    vector = _path_vectors(self.mesh, intent, node_path, edge_ids)
                    effects = [self.mesh.events[e].effect_for(intent_id) for e in edge_ids]
                    revisions = [str(e["revision_text"]) for e in effects if e["revise_intent"] and str(e["revision_text"]).strip()]
                    raw.append(SemanticTrajectory(
                        id=_stable_id([intent_id, *node_path, *edge_ids]),
                        intent_id=intent_id,
                        trace_path=list(node_path),
                        transform_path=edge_ids,
                        vector=vector,
                        revises_intent=bool(revisions),
                        revision_texts=revisions,
                    ))
                if len(raw) >= max_paths:
                    break
            if len(raw) >= max_paths:
                break
        return raw

    @staticmethod
    def pareto(trajectories: Sequence[SemanticTrajectory]) -> List[SemanticTrajectory]:
        out: List[SemanticTrajectory] = []
        for candidate in trajectories:
            dominated = False
            for other in trajectories:
                if other.id == candidate.id:
                    continue
                if other.vector.dominates(candidate.vector):
                    dominated = True
                    break
            if not dominated:
                out.append(candidate)
        out.sort(key=lambda x: (
            -x.vector.intent_advance,
            -x.vector.evidence_floor,
            -x.vector.reversibility_floor,
            -x.vector.observer_diversity,
            x.id,
        ))
        return out
