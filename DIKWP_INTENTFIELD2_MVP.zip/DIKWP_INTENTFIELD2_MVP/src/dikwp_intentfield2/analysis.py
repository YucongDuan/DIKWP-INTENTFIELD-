from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .audit import NoDefinitionAudit
from .erasure import ConceptErasureEngine
from .experiments import ActionHypothesisCompiler
from .kernel import ProblemKernelMiner
from .mesh import IntentSemanticMesh
from .models import InquiryBundle, SemanticTrajectory
from .residuals import ResidualAxisLab
from .trajectory import TrajectoryExplorer
from .transforms import TransformRegistry


class IntentFieldAnalyzer:
    def __init__(self, bundle: InquiryBundle) -> None:
        bundle.validate()
        self.bundle = bundle
        self.mesh = IntentSemanticMesh(bundle)

    def _analyze_core(self, max_depth: int = 6) -> Dict[str, Any]:
        explorer = TrajectoryExplorer(self.mesh)
        all_trajectories: List[SemanticTrajectory] = []
        pareto_trajectories: List[SemanticTrajectory] = []
        problem_kernel: List[Dict[str, Any]] = []
        intent_revisions: List[Dict[str, Any]] = []
        trajectory_counts: Dict[str, Dict[str, int]] = {}

        for intent in self.bundle.intents:
            raw = explorer.enumerate(intent.id, max_depth=max_depth)
            pareto = explorer.pareto(raw)
            all_trajectories.extend(raw)
            pareto_trajectories.extend(pareto)
            problem_kernel.extend(ProblemKernelMiner(self.mesh).mine(intent.id, pareto))
            trajectory_counts[intent.id] = {"enumerated": len(raw), "pareto": len(pareto)}
            seen_revision = set()
            for trajectory in pareto:
                for text in trajectory.revision_texts:
                    key = (intent.id, text)
                    if key in seen_revision:
                        continue
                    seen_revision.add(key)
                    intent_revisions.append({
                        "intent_id": intent.id,
                        "source_trajectory": trajectory.id,
                        "proposal": text,
                        "status": "proposal-not-automatic-update",
                    })

        residual_axes = ResidualAxisLab(self.mesh).discover()
        experiments = ActionHypothesisCompiler(self.mesh).compile(problem_kernel, residual_axes)
        transform_registry = TransformRegistry()
        usage = Counter(self.mesh.used_transform_types())
        transformation_tensor = []
        for event in self.bundle.transformations:
            source = self.mesh.traces[event.source]
            target = self.mesh.traces[event.target]
            transformation_tensor.append({
                "event_id": event.id,
                "primitive": event.transform_type,
                "observer": event.observer,
                "source_context": source.context,
                "target_context": target.context,
                "source_modality": source.modality,
                "target_modality": target.modality,
                "source_scale": source.scale,
                "target_scale": target.scale,
                "time": [source.time, target.time],
                "provenance": event.provenance,
                "meta_rule": event.meta_rule,
            })

        # Show which kernel relations persist or change under different intents.
        by_intent: Dict[str, set[tuple[str, str]]] = defaultdict(set)
        for item in problem_kernel:
            by_intent[str(item["intent_id"])].add((str(item["relation_id"]), str(item["kernel_role"])))
        intent_ids = [i.id for i in self.bundle.intents]
        if intent_ids:
            stable = set.intersection(*(by_intent[i] for i in intent_ids)) if all(by_intent[i] for i in intent_ids) else set()
            union = set.union(*(by_intent[i] for i in intent_ids)) if any(by_intent[i] for i in intent_ids) else set()
        else:
            stable = set()
            union = set()
        intent_comparison = {
            "intent_ids": intent_ids,
            "shared_kernel_relations": [{"relation_id": r, "kernel_role": role} for r, role in sorted(stable)],
            "intent_sensitive_relations": [{"relation_id": r, "kernel_role": role} for r, role in sorted(union - stable)],
            "interpretation": "Shared relations remain relevant across the supplied intents; intent-sensitive relations reveal where a claimed essence would merely encode one agenda.",
        }

        cycles = self.mesh.cycles()
        result: Dict[str, Any] = {
            "system": "DIKWP-INTENTFIELD²",
            "inquiry_id": self.bundle.inquiry_id,
            "surface_prompt": self.bundle.surface_prompt,
            "output_contract": "intent-indexed semantic navigation; no concept definition or final categorical label",
            "intents": [x.to_dict() for x in self.bundle.intents],
            "trajectory_counts": trajectory_counts,
            "pareto_trajectories": [x.to_dict() for x in pareto_trajectories],
            "problem_kernel": problem_kernel,
            "intent_revisions": intent_revisions,
            "intent_comparison": intent_comparison,
            "residual_axes": residual_axes,
            "action_hypotheses": experiments,
            "transformation_registry": [x.to_dict() for x in transform_registry.all()],
            "transformation_usage": {k: usage.get(k, 0) for k in transform_registry.coverage(usage)["used"] + transform_registry.coverage(usage)["missing"]},
            "transformation_coverage": transform_registry.coverage(usage),
            "transformation_tensor": transformation_tensor,
            "directed_cycles": cycles,
            "observer_transformation_map": self.mesh.observer_transformation_map(),
            "no_definition_principles": [
                "surface labels are entry handles, not ontological endpoints",
                "intent biases routes but is revisable by every DIKWP resource type",
                "no scalar score substitutes for plurality of evidence, values and purposes",
                "residual coordinates remain unnamed until independent discrimination",
                "problem kernels are intent-indexed intervention sets, not universal essences",
            ],
        }
        return result

    def analyze(self, max_depth: int = 6, run_erasure: bool = True) -> Dict[str, Any]:
        result = self._analyze_core(max_depth=max_depth)
        if run_erasure:
            masked_bundle = ConceptErasureEngine().mask_bundle(self.bundle)
            masked_result = IntentFieldAnalyzer(masked_bundle).analyze(max_depth=max_depth, run_erasure=False)
            result["concept_erasure_audit"] = ConceptErasureEngine.compare(result, masked_result)
            result["masked_surface_prompt"] = masked_bundle.surface_prompt
        else:
            result["concept_erasure_audit"] = {"status": "not-run"}

        audit = NoDefinitionAudit(self.mesh).run(result)
        result["no_definition_audit"] = audit
        return result
