from __future__ import annotations

import copy
import re
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from .models import InquiryBundle


def _mask_text(text: str, anchors: Sequence[str]) -> str:
    out = text
    # Longest first avoids partial masking of multi-character anchors.
    for idx, anchor in enumerate(sorted({a for a in anchors if a}, key=len, reverse=True), start=1):
        out = re.sub(re.escape(anchor), f"⟦A{idx:02d}⟧", out, flags=re.IGNORECASE)
    return out


class ConceptErasureEngine:
    """Removes surface anchors while retaining relations, provenance and intent links.

    If the system's problem kernel changes solely because a familiar word was
    hidden or renamed, the analysis is concept-locked rather than semantic.
    """

    def mask_bundle(self, bundle: InquiryBundle) -> InquiryBundle:
        clone = copy.deepcopy(bundle)
        anchors = clone.anchor_terms
        clone.surface_prompt = _mask_text(clone.surface_prompt, anchors)
        for trace in clone.traces:
            trace.text = _mask_text(trace.text, anchors)
            trace.lexical_anchors = [f"MASKED-{i+1}" for i, _ in enumerate(trace.lexical_anchors)]
        for event in clone.transformations:
            event.relation_text = _mask_text(event.relation_text, anchors)
            for intent_id, effect in event.intent_effects.items():
                if "revision_text" in effect:
                    effect["revision_text"] = _mask_text(str(effect["revision_text"]), anchors)
        for intent in clone.intents:
            intent.desired_change = _mask_text(intent.desired_change, anchors)
            intent.preserve = [_mask_text(x, anchors) for x in intent.preserve]
            intent.avoid = [_mask_text(x, anchors) for x in intent.avoid]
        clone.metadata = dict(clone.metadata)
        clone.metadata["concept_erasure"] = "surface anchors masked; graph and provenance unchanged"
        clone.validate()
        return clone

    @staticmethod
    def compare(original: Mapping[str, Any], masked: Mapping[str, Any]) -> Dict[str, Any]:
        original_kernel = {
            (x.get("intent_id"), x.get("relation_id"), x.get("kernel_role"))
            for x in original.get("problem_kernel", [])
        }
        masked_kernel = {
            (x.get("intent_id"), x.get("relation_id"), x.get("kernel_role"))
            for x in masked.get("problem_kernel", [])
        }
        original_routes = {
            (x.get("intent_id"), tuple(x.get("transform_path", [])))
            for x in original.get("pareto_trajectories", [])
        }
        masked_routes = {
            (x.get("intent_id"), tuple(x.get("transform_path", [])))
            for x in masked.get("pareto_trajectories", [])
        }
        kernel_union = original_kernel | masked_kernel
        route_union = original_routes | masked_routes
        kernel_jaccard = len(original_kernel & masked_kernel) / max(1, len(kernel_union))
        route_jaccard = len(original_routes & masked_routes) / max(1, len(route_union))
        return {
            "kernel_jaccard": round(kernel_jaccard, 6),
            "trajectory_jaccard": round(route_jaccard, 6),
            "passed": kernel_jaccard >= 0.95 and route_jaccard >= 0.95,
            "interpretation": (
                "The inquiry remains stable after concept-label masking; structure, intent and provenance—not lexical anchors—drive the result."
                if kernel_jaccard >= 0.95 and route_jaccard >= 0.95
                else "The inquiry changes materially after label masking; inspect concept-lock, hidden taxonomies or text-only heuristics."
            ),
        }
