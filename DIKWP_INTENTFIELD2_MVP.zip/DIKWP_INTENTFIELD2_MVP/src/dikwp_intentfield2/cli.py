from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any, Dict

from .analysis import IntentFieldAnalyzer
from .dashboard import render_dashboard
from .io import dump_json, load_bundle
from .mesh import IntentSemanticMesh
from .visualize import (
    plot_dikwp_mesh,
    plot_erasure_audit,
    plot_intent_kernel_comparison,
    plot_problem_kernel,
    plot_trajectory_vectors,
)


def _write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def run_analyze(input_path: str, out_dir: str, max_depth: int) -> Dict[str, Any]:
    bundle = load_bundle(input_path)
    analyzer = IntentFieldAnalyzer(bundle)
    result = analyzer.analyze(max_depth=max_depth, run_erasure=True)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    dump_json(out / "intentfield_result.json", result)
    dump_json(out / "problem_kernel.json", result["problem_kernel"])
    dump_json(out / "pareto_trajectories.json", result["pareto_trajectories"])
    dump_json(out / "residual_axes.json", result["residual_axes"])
    dump_json(out / "action_hypotheses.json", result["action_hypotheses"])
    dump_json(out / "concept_erasure_audit.json", result["concept_erasure_audit"])
    dump_json(out / "no_definition_audit.json", result["no_definition_audit"])
    dump_json(out / "transformation_tensor.json", result["transformation_tensor"])
    _write_csv(out / "problem_kernel.csv", result["problem_kernel"], [
        "intent_id","kernel_role","relation_id","transform_type","observer","relation_text",
        "counterfactual_reachability_impact","pareto_route_share","provenance"
    ])
    trajectory_rows = []
    for item in result["pareto_trajectories"]:
        row = {
            "intent_id": item["intent_id"],
            "trajectory_id": item["id"],
            "trace_path": " -> ".join(item["trace_path"]),
            "transform_path": " / ".join(item["transform_path"]),
            **item["vector"],
            "revises_intent": item["revises_intent"],
        }
        trajectory_rows.append(row)
    _write_csv(out / "pareto_trajectories.csv", trajectory_rows, [
        "intent_id","trajectory_id","trace_path","transform_path","evidence_floor","intent_advance",
        "reversibility_floor","observer_diversity","residual_preservation","transformation_diversity",
        "power_symmetry","uncertainty_fit","revises_intent"
    ])

    mesh = IntentSemanticMesh(bundle)
    fig_dir = out / "figures"
    fig_dir.mkdir(exist_ok=True)
    plot_dikwp_mesh(mesh, fig_dir / "dikwp_intent_mesh.png")
    plot_problem_kernel(mesh, result, fig_dir / "problem_kernel.png")
    plot_trajectory_vectors(result, fig_dir / "trajectory_pareto.png")
    plot_erasure_audit(result, fig_dir / "concept_erasure.png")
    plot_intent_kernel_comparison(result, fig_dir / "intent_comparison.png")
    figures = {
        "DIKWP×DIKWP网状变换": "figures/dikwp_intent_mesh.png",
        "意图索引问题核": "figures/problem_kernel.png",
        "Pareto语义路径": "figures/trajectory_pareto.png",
        "概念词遮蔽审计": "figures/concept_erasure.png",
        "不同意图的问题核差异": "figures/intent_comparison.png",
    }
    render_dashboard(result, out / "dashboard.html", figures=figures)
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="DIKWP-INTENTFIELD² definition-free semantic field analyzer")
    sub = parser.add_subparsers(dest="command", required=True)
    p_analyze = sub.add_parser("analyze", help="Analyze an intent-field inquiry bundle")
    p_analyze.add_argument("input")
    p_analyze.add_argument("--out", default="outputs")
    p_analyze.add_argument("--max-depth", type=int, default=6)
    args = parser.parse_args()
    if args.command == "analyze":
        result = run_analyze(args.input, args.out, args.max_depth)
        print(json.dumps({
            "inquiry_id": result["inquiry_id"],
            "pareto_trajectories": len(result["pareto_trajectories"]),
            "problem_kernel": len(result["problem_kernel"]),
            "residual_axes": len(result["residual_axes"]),
            "concept_erasure_passed": result["concept_erasure_audit"].get("passed"),
            "no_definition_audit": result["no_definition_audit"].get("status"),
        }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
