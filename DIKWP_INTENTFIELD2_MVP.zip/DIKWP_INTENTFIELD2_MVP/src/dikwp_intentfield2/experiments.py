from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Sequence

from .mesh import IntentSemanticMesh


class ActionHypothesisCompiler:
    """Compiles reversible discrimination actions, not final semantic answers."""

    def __init__(self, mesh: IntentSemanticMesh) -> None:
        self.mesh = mesh

    def compile(self, kernel: Sequence[Mapping[str, Any]], residual_axes: Sequence[Mapping[str, Any]]) -> List[Dict[str, Any]]:
        plans: List[Dict[str, Any]] = []
        for idx, item in enumerate(kernel, start=1):
            event = self.mesh.events[str(item["relation_id"])]
            role = str(item["kernel_role"])
            action_kind = {
                "obstruction": "bounded-perturbation",
                "preservation": "non-destruction-and-monitoring",
                "discrimination": "comparative-observation",
                "revision": "intent-review",
                "route-bridge": "trace-and-replay",
            }.get(role, "comparative-observation")
            stop_conditions = [
                "出现未登记的不可逆影响",
                "受影响方撤回授权",
                "证据来源或时间顺序无法追溯",
                "实验开始替代而不是检验当前意图",
            ]
            plans.append({
                "experiment_id": f"EXP-{idx:04d}",
                "intent_id": item["intent_id"],
                "target_relation": item["relation_id"],
                "action_kind": action_kind,
                "question": f"在不预设概念边界的情况下，怎样通过可逆操作检验该关系对当前意图路径的真实影响：{event.relation_text}",
                "pre_action_prediction_required": True,
                "counterfactual_required": True,
                "observer_rotation_required": True,
                "scale_rotation_required": True,
                "reversibility": event.reversibility,
                "affected_parties": event.affected_parties,
                "provenance": event.provenance,
                "stop_conditions": stop_conditions,
                "result_options": [
                    "relation-supported-in-this-context",
                    "relation-weakened-in-this-context",
                    "alternative-route-supported",
                    "intent-must-be-revised",
                    "unresolved-residual-increased",
                ],
                "prohibited_result": "a universal definition or observer-free essence claim",
            })
        offset = len(plans)
        for j, axis in enumerate(residual_axes, start=1):
            plans.append({
                "experiment_id": f"EXP-{offset+j:04d}",
                "intent_id": "cross-intent",
                "target_relation": axis["axis_id"],
                "action_kind": "unnamed-coordinate-discrimination",
                "question": "检验该未命名残差坐标是否真正改变语义路径，而不是给旧关系换名。",
                "pre_action_prediction_required": True,
                "counterfactual_required": True,
                "observer_rotation_required": True,
                "scale_rotation_required": True,
                "reversibility": 1.0,
                "affected_parties": [],
                "provenance": axis["provenance"],
                "stop_conditions": ["测试不能区分任何路线", "新坐标只复制现有关系", "只有单一观察者支持"],
                "result_options": ["retain-unnamed-coordinate", "merge-with-existing-relation", "discard", "collect-more-traces"],
                "prohibited_result": "naming the coordinate as a settled concept before replication",
            })
        return plans
