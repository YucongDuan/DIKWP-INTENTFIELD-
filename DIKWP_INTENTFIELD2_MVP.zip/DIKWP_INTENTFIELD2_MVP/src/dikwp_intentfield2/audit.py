from __future__ import annotations

import json
import re
from collections import Counter
from typing import Any, Dict, Iterable, List, Mapping, Sequence

from .mesh import IntentSemanticMesh
from .transforms import TransformRegistry


_DEFINITION_PATTERNS = [
    re.compile(r"定义为"),
    re.compile(r"本质是"),
    re.compile(r"唯一真正的"),
    re.compile(r"is\s+defined\s+as", re.I),
    re.compile(r"the\s+essence\s+is", re.I),
]


class NoDefinitionAudit:
    def __init__(self, mesh: IntentSemanticMesh) -> None:
        self.mesh = mesh

    def run(self, generated: Mapping[str, Any] | None = None) -> Dict[str, Any]:
        issues: List[Dict[str, str]] = []
        raw_bundle = self.mesh.bundle.to_dict()
        top_fields = set(raw_bundle)
        forbidden_fields = {"concept", "definition", "concept_registry", "final_label", "ontology_root"}
        for field in sorted(top_fields & forbidden_fields):
            issues.append({"code": "CONCEPT_LOCK_FIELD", "severity": "high", "detail": field})

        coverage = TransformRegistry().coverage(self.mesh.used_transform_types())
        if coverage["coverage"] < 1.0:
            issues.append({
                "code": "INCOMPLETE_DIKWP_X_DIKWP_COVERAGE",
                "severity": "medium",
                "detail": ", ".join(coverage["missing"]),
            })

        source_types = Counter(e.source_type.value for e in self.mesh.events.values())
        target_types = Counter(e.target_type.value for e in self.mesh.events.values())
        if target_types.get("P", 0) == 0 or source_types.get("P", 0) == 0:
            issues.append({"code": "PURPOSE_NOT_MUTUALLY_REVISABLE", "severity": "high", "detail": "P must both transform and be transformed."})

        observers = self.mesh.observers()
        if len(observers) < 3:
            issues.append({"code": "OBSERVER_COLLAPSE", "severity": "medium", "detail": "Fewer than three independent observer positions."})

        if generated is not None:
            text = json.dumps(generated, ensure_ascii=False)
            for pattern in _DEFINITION_PATTERNS:
                if pattern.search(text):
                    issues.append({"code": "FINAL_DEFINITION_LANGUAGE", "severity": "high", "detail": pattern.pattern})
            if "aggregate_score" in text or "truth_score" in text or "essence_score" in text:
                issues.append({"code": "SCALAR_TRUTH_COLLAPSE", "severity": "high", "detail": "A single scalar is used as a truth substitute."})
            for item in generated.get("problem_kernel", []):
                if not item.get("intent_id") or not item.get("provenance"):
                    issues.append({"code": "UNINDEXED_KERNEL", "severity": "high", "detail": str(item.get("relation_id"))})
            for axis in generated.get("residual_axes", []):
                if axis.get("provisional_name") not in (None, "", []):
                    issues.append({"code": "PREMATURE_AXIS_NAMING", "severity": "medium", "detail": str(axis.get("axis_id"))})

        severity_rank = {"low": 1, "medium": 2, "high": 3}
        max_severity = max((severity_rank[x["severity"]] for x in issues), default=0)
        return {
            "status": "PASS" if max_severity < 2 else "REVIEW" if max_severity == 2 else "FAIL",
            "issues": issues,
            "checks": {
                "no_top_level_concept_field": not bool(top_fields & forbidden_fields),
                "all_25_transform_types_present": coverage["coverage"] == 1.0,
                "purpose_is_bidirectional": target_types.get("P", 0) > 0 and source_types.get("P", 0) > 0,
                "multi_observer": len(observers) >= 3,
                "no_final_definition_language": not any(x["code"] == "FINAL_DEFINITION_LANGUAGE" for x in issues),
                "no_scalar_truth_collapse": not any(x["code"] == "SCALAR_TRUTH_COLLAPSE" for x in issues),
                "all_kernel_items_intent_and_provenance_indexed": not any(x["code"] == "UNINDEXED_KERNEL" for x in issues),
                "unnamed_residual_coordinates": not any(x["code"] == "PREMATURE_AXIS_NAMING" for x in issues),
            },
            "transformation_coverage": coverage,
        }
