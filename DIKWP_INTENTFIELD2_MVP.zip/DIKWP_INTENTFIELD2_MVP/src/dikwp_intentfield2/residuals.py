from __future__ import annotations

from collections import defaultdict
from itertools import combinations
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set, Tuple

from .mesh import IntentSemanticMesh


def _jaccard(a: Set[str], b: Set[str]) -> float:
    if not a and not b:
        return 1.0
    return len(a & b) / max(1, len(a | b))


class ResidualAxisLab:
    """Clusters unresolved residues without naming a new concept or dimension.

    Each cluster receives an opaque UAX id and a discriminating test plan. A human
    community may later attach a provisional descriptor, but the engine itself
    does not install a named ontology axis.
    """

    def __init__(self, mesh: IntentSemanticMesh) -> None:
        self.mesh = mesh

    def discover(self, min_similarity: float = 0.42) -> List[Dict[str, Any]]:
        entries: List[Dict[str, Any]] = []
        for event in self.mesh.events.values():
            for residual in event.residuals:
                signature = {
                    event.transform_type,
                    f"observer:{event.observer}",
                    *(f"party:{p}" for p in event.affected_parties),
                    *(f"intent:{i}" for i in event.intent_effects),
                }
                entries.append({
                    "residual": residual,
                    "event_id": event.id,
                    "relation_text": event.relation_text,
                    "signature": signature,
                    "observer": event.observer,
                    "provenance": event.provenance,
                })
        clusters: List[List[Dict[str, Any]]] = []
        for entry in entries:
            placed = False
            for cluster in clusters:
                union_signature = set().union(*(x["signature"] for x in cluster))
                if _jaccard(entry["signature"], union_signature) >= min_similarity:
                    cluster.append(entry)
                    placed = True
                    break
            if not placed:
                clusters.append([entry])

        out: List[Dict[str, Any]] = []
        for idx, cluster in enumerate(clusters, start=1):
            observers = sorted({x["observer"] for x in cluster})
            events = sorted({x["event_id"] for x in cluster})
            residual_texts = [x["residual"] for x in cluster]
            relation_texts = [x["relation_text"] for x in cluster]
            tests = []
            for a, b in combinations(cluster[:4], 2):
                tests.append({
                    "hold_fixed": a["event_id"],
                    "perturb": b["event_id"],
                    "question": f"在保持“{a['relation_text']}”对应条件不变时，改变“{b['relation_text']}”对应条件，意图路径是否发生可重复变化？",
                })
            if not tests and cluster:
                tests.append({
                    "hold_fixed": "current-boundary-and-provenance",
                    "perturb": cluster[0]["event_id"],
                    "question": f"对“{cluster[0]['relation_text']}”进行可逆干预，是否出现现有DIKWP变换无法表示的稳定差异？",
                })
            out.append({
                "axis_id": f"UAX-{idx:04d}",
                "status": "unnamed-residual-coordinate-candidate",
                "provisional_name": None,
                "residual_instances": residual_texts,
                "source_events": events,
                "observers": observers,
                "provenance": sorted({x["provenance"] for x in cluster}),
                "discriminating_tests": tests,
                "promotion_rule": "Only after independent observers reproduce a differentiating effect may a provisional descriptor be proposed; no concept definition is installed.",
                "rollback_rule": "Remove or merge the coordinate if tests fail to distinguish routes or if it merely renames an existing relation.",
            })
        return out
