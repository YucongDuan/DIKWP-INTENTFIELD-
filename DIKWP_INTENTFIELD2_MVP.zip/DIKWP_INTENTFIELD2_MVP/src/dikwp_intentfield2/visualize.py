from __future__ import annotations

from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence

import matplotlib.pyplot as plt
import networkx as nx

from .mesh import IntentSemanticMesh


FONT = "Noto Sans CJK JP"
plt.rcParams["font.family"] = FONT
plt.rcParams["axes.unicode_minus"] = False


_TYPE_COLOR = {
    "D": "#3B82F6",
    "I": "#14B8A6",
    "K": "#8B5CF6",
    "W": "#F59E0B",
    "P": "#EF4444",
}


def plot_dikwp_mesh(mesh: IntentSemanticMesh, path: str | Path) -> None:
    g = nx.DiGraph()
    for typ in ["D", "I", "K", "W", "P"]:
        g.add_node(typ)
    counts = Counter(mesh.used_transform_types())
    for src in ["D", "I", "K", "W", "P"]:
        for dst in ["D", "I", "K", "W", "P"]:
            g.add_edge(src, dst, weight=max(1, counts.get(f"{src}->{dst}", 0)))
    pos = nx.circular_layout(g, scale=1.0)
    fig, ax = plt.subplots(figsize=(8.5, 7.2))
    nx.draw_networkx_nodes(g, pos, node_size=2800, node_color=[_TYPE_COLOR[n] for n in g.nodes], ax=ax, linewidths=1.5, edgecolors="white")
    nx.draw_networkx_labels(g, pos, labels={n: n for n in g.nodes}, font_size=18, font_weight="bold", font_color="white", ax=ax)
    for u, v in g.edges:
        rad = 0.12 if u != v else 0.38
        nx.draw_networkx_edges(g, pos, edgelist=[(u, v)], connectionstyle=f"arc3,rad={rad}", arrowstyle="-|>", arrowsize=12, width=0.7, alpha=0.42, edge_color="#334155", ax=ax)
    ax.text(0, 0, "意图场 Φ(t)\n动态偏置而非最高控制器", ha="center", va="center", fontsize=13, bbox=dict(boxstyle="round,pad=0.5", fc="#F8FAFC", ec="#64748B", lw=1.2))
    ax.set_title("DIKWP×DIKWP网状变换与可修订意图场", fontsize=16, pad=16)
    ax.axis("off")
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_problem_kernel(mesh: IntentSemanticMesh, result: Mapping[str, Any], path: str | Path, intent_id: str | None = None) -> None:
    if intent_id is None:
        intent_id = mesh.bundle.intents[0].id
    g = nx.DiGraph()
    for trace in mesh.bundle.traces:
        g.add_node(trace.id, label=trace.id, typ=trace.dominant_type.value)
    kernel_ids = {x["relation_id"] for x in result.get("problem_kernel", []) if x["intent_id"] == intent_id}
    for event in mesh.bundle.transformations:
        g.add_edge(event.source, event.target, event_id=event.id, kernel=event.id in kernel_ids)
    pos = nx.spring_layout(g, seed=17, k=0.7)
    fig, ax = plt.subplots(figsize=(10.5, 8.0))
    nx.draw_networkx_nodes(g, pos, node_size=650, node_color=[_TYPE_COLOR[g.nodes[n]["typ"]] for n in g.nodes], edgecolors="white", linewidths=0.8, ax=ax)
    nx.draw_networkx_labels(g, pos, labels={n: n for n in g.nodes}, font_size=7.5, font_color="white", ax=ax)
    normal = [(u, v) for u, v, d in g.edges(data=True) if not d["kernel"]]
    kernel = [(u, v) for u, v, d in g.edges(data=True) if d["kernel"]]
    nx.draw_networkx_edges(g, pos, edgelist=normal, width=0.7, alpha=0.20, edge_color="#64748B", arrowsize=7, ax=ax)
    nx.draw_networkx_edges(g, pos, edgelist=kernel, width=2.4, alpha=0.95, edge_color="#DC2626", arrowsize=12, ax=ax)
    ax.set_title(f"意图 {intent_id} 的问题核：红色关系是干预相关，不是概念定义", fontsize=15)
    ax.axis("off")
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_trajectory_vectors(result: Mapping[str, Any], path: str | Path) -> None:
    trajectories = result.get("pareto_trajectories", [])
    fig, ax = plt.subplots(figsize=(9.0, 6.2))
    intents = sorted({t["intent_id"] for t in trajectories})
    markers = ["o", "s", "^", "D", "P"]
    for idx, intent in enumerate(intents):
        subset = [t for t in trajectories if t["intent_id"] == intent]
        x = [t["vector"]["evidence_floor"] for t in subset]
        y = [t["vector"]["intent_advance"] for t in subset]
        sizes = [70 + 240 * t["vector"]["observer_diversity"] for t in subset]
        ax.scatter(x, y, s=sizes, alpha=0.75, marker=markers[idx % len(markers)], label=intent, edgecolors="white", linewidths=0.7)
    ax.set_xlabel("证据下界")
    ax.set_ylabel("当前意图推进度")
    ax.set_title("非标量化的Pareto语义路径：点大小表示观察者多样性")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_erasure_audit(result: Mapping[str, Any], path: str | Path) -> None:
    audit = result.get("concept_erasure_audit", {})
    labels = ["问题核稳定度", "路径稳定度"]
    values = [audit.get("kernel_jaccard", 0.0), audit.get("trajectory_jaccard", 0.0)]
    fig, ax = plt.subplots(figsize=(7.0, 4.8))
    bars = ax.bar(labels, values, width=0.52, color=["#0EA5E9", "#22C55E"])
    ax.axhline(0.95, color="#DC2626", linestyle="--", linewidth=1.2, label="通过阈值（工程审计）")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Jaccard一致度")
    ax.set_title("概念词遮蔽后，语义分析是否仍保持")
    for bar, value in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width()/2, value + 0.025, f"{value:.3f}", ha="center", fontsize=11)
    ax.legend()
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)


def plot_intent_kernel_comparison(result: Mapping[str, Any], path: str | Path) -> None:
    kernel = result.get("problem_kernel", [])
    intents = sorted({x["intent_id"] for x in kernel})
    roles = ["obstruction", "preservation", "discrimination", "revision", "route-bridge"]
    counts = {intent: Counter(x["kernel_role"] for x in kernel if x["intent_id"] == intent) for intent in intents}
    fig, ax = plt.subplots(figsize=(9.0, 5.8))
    bottom = [0] * len(intents)
    palette = ["#DC2626", "#16A34A", "#2563EB", "#9333EA", "#64748B"]
    for role, color in zip(roles, palette):
        vals = [counts[i].get(role, 0) for i in intents]
        ax.bar(intents, vals, bottom=bottom, label=role, color=color)
        bottom = [a+b for a,b in zip(bottom, vals)]
    ax.set_ylabel("问题核关系数")
    ax.set_title("不同意图产生不同问题核：避免把一个议程伪装成普遍本质")
    ax.legend(ncol=3, fontsize=8)
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
