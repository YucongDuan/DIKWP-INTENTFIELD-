from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Mapping, Sequence, Set, Tuple

import networkx as nx

from .models import InquiryBundle, IntentPulse, SemanticTrace, TransformEvent


class IntentSemanticMesh:
    """A definition-free semantic multigraph driven by revisable intent fields."""

    def __init__(self, bundle: InquiryBundle) -> None:
        self.bundle = bundle
        self.graph = nx.MultiDiGraph(inquiry_id=bundle.inquiry_id)
        self.traces: Dict[str, SemanticTrace] = bundle.trace_map()
        self.events: Dict[str, TransformEvent] = {e.id: e for e in bundle.transformations}
        self.intents: Dict[str, IntentPulse] = bundle.intent_map()
        for trace in bundle.traces:
            self.graph.add_node(
                trace.id,
                kind="trace",
                observer=trace.observer,
                dominant_type=trace.dominant_type.value,
                trace=trace,
            )
        for event in bundle.transformations:
            self.graph.add_edge(
                event.source,
                event.target,
                key=event.id,
                kind="transform",
                event=event,
                transform_type=event.transform_type,
            )

    def used_transform_types(self) -> List[str]:
        return [e.transform_type for e in self.events.values()]

    def observers(self) -> Set[str]:
        return {t.observer for t in self.traces.values()}

    def intent_subgraph(self, intent_id: str) -> nx.MultiDiGraph:
        if intent_id not in self.intents:
            raise KeyError(intent_id)
        g = nx.MultiDiGraph(inquiry_id=self.bundle.inquiry_id, intent_id=intent_id)
        for node, data in self.graph.nodes(data=True):
            g.add_node(node, **data)
        for u, v, key, data in self.graph.edges(keys=True, data=True):
            event: TransformEvent = data["event"]
            effect = event.effect_for(intent_id)
            g.add_edge(u, v, key=key, **data, intent_effect=effect)
        return g

    def cycles(self) -> List[List[str]]:
        simple = nx.DiGraph()
        simple.add_nodes_from(self.graph.nodes)
        simple.add_edges_from((u, v) for u, v in self.graph.edges())
        return list(nx.simple_cycles(simple))

    def transformation_matrix(self) -> Dict[str, int]:
        counts = Counter(self.used_transform_types())
        return {k: counts.get(k, 0) for k in sorted(counts | {x: 0 for x in []})}

    def observer_transformation_map(self) -> Dict[str, Dict[str, int]]:
        out: Dict[str, Counter[str]] = defaultdict(Counter)
        for event in self.events.values():
            out[event.observer][event.transform_type] += 1
        return {obs: dict(sorted(counter.items())) for obs, counter in sorted(out.items())}
