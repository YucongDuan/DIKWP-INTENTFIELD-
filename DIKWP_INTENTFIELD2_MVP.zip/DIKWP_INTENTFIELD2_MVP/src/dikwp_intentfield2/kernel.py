from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Set, Tuple

import networkx as nx

from .mesh import IntentSemanticMesh
from .models import SemanticTrajectory


class ProblemKernelMiner:
    """Finds a minimal intervention-relevant relation set, not a concept essence.

    Kernel roles are intent-indexed:
      * obstruction: blocks admissible movement;
      * preservation: must not be destroyed while pursuing the intent;
      * discrimination: distinguishes routes or lowers uncertainty;
      * revision: can legitimately alter the intent field itself.
    """

    def __init__(self, mesh: IntentSemanticMesh) -> None:
        self.mesh = mesh

    def _reachability_without(self, intent_id: str, removed_event: str) -> int:
        intent = self.mesh.intents[intent_id]
        g = nx.DiGraph()
        g.add_nodes_from(self.mesh.graph.nodes)
        for event in self.mesh.events.values():
            if event.id == removed_event:
                continue
            effect = event.effect_for(intent_id)
            # A fully blocking edge is not considered admissible.
            if float(effect["block"]) >= 0.95:
                continue
            g.add_edge(event.source, event.target)
        total = 0
        for start in intent.start_traces:
            for goal in intent.goal_traces:
                if start != goal and nx.has_path(g, start, goal):
                    total += 1
        return total

    def mine(self, intent_id: str, pareto: Sequence[SemanticTrajectory]) -> List[Dict[str, Any]]:
        intent = self.mesh.intents[intent_id]
        frequency = Counter()
        route_coverage: Dict[str, Set[str]] = defaultdict(set)
        for trajectory in pareto:
            for event_id in trajectory.transform_path:
                frequency[event_id] += 1
                route_coverage[event_id].add(trajectory.id)

        base_reachability = self._reachability_without(intent_id, removed_event="__none__")
        candidates: List[Dict[str, Any]] = []
        for event_id, event in self.mesh.events.items():
            effect = event.effect_for(intent_id)
            role = None
            magnitude = 0.0
            if float(effect["block"]) >= 0.45:
                role = "obstruction"
                magnitude = float(effect["block"])
            elif float(effect["preserve"]) >= 0.45:
                role = "preservation"
                magnitude = float(effect["preserve"])
            elif effect["revise_intent"]:
                role = "revision"
                magnitude = max(0.5, abs(float(effect["advance"])))
            elif float(effect["uncertainty"]) >= max(0.55, intent.uncertainty_tolerance):
                role = "discrimination"
                magnitude = float(effect["uncertainty"])
            if role is None and frequency[event_id] == 0:
                continue
            reach_without = self._reachability_without(intent_id, event_id)
            reach_impact = (base_reachability - reach_without) / max(1, base_reachability)
            route_share = frequency[event_id] / max(1, len(pareto))
            candidates.append({
                "intent_id": intent_id,
                "relation_id": event_id,
                "kernel_role": role or "route-bridge",
                "relation_text": event.relation_text,
                "transform_type": event.transform_type,
                "observer": event.observer,
                "provenance": event.provenance,
                "magnitude": round(magnitude, 6),
                "pareto_route_share": round(route_share, 6),
                "counterfactual_reachability_impact": round(reach_impact, 6),
                "residuals": list(event.residuals),
                "affected_parties": list(event.affected_parties),
                "why_selected": "Selected for intent-specific obstruction/preservation/discrimination/revision or route-bridge impact; not asserted as a definition.",
            })

        # Greedy compactness: preserve high-impact items while ensuring each role
        # represented when available. No single scalar is published as a truth score.
        by_role: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        for item in candidates:
            by_role[item["kernel_role"]].append(item)
        selected: List[Dict[str, Any]] = []
        for role, items in sorted(by_role.items()):
            items.sort(key=lambda x: (
                -float(x["counterfactual_reachability_impact"]),
                -float(x["pareto_route_share"]),
                -float(x["magnitude"]),
                str(x["relation_id"]),
            ))
            selected.extend(items[:3])

        # Add frequent bridges if not already present.
        selected_ids = {x["relation_id"] for x in selected}
        bridges = sorted(
            [x for x in candidates if x["relation_id"] not in selected_ids],
            key=lambda x: (-float(x["pareto_route_share"]), -float(x["counterfactual_reachability_impact"]), str(x["relation_id"])),
        )
        selected.extend(bridges[:2])
        selected.sort(key=lambda x: (str(x["kernel_role"]), -float(x["counterfactual_reachability_impact"]), str(x["relation_id"])))
        return selected
