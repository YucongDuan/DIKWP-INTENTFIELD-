from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple


class DIKWPType(str, Enum):
    D = "D"
    I = "I"
    K = "K"
    W = "W"
    P = "P"

    @classmethod
    def ordered(cls) -> Tuple["DIKWPType", ...]:
        return (cls.D, cls.I, cls.K, cls.W, cls.P)

    @classmethod
    def pairs(cls) -> Tuple[str, ...]:
        return tuple(f"{a.value}->{b.value}" for a in cls.ordered() for b in cls.ordered())


def normalize_weights(weights: Mapping[str | DIKWPType, float]) -> Dict[str, float]:
    out = {t.value: 0.0 for t in DIKWPType.ordered()}
    for key, value in weights.items():
        k = key.value if isinstance(key, DIKWPType) else str(key).upper()
        if k not in out:
            raise ValueError(f"Unknown DIKWP type: {key}")
        out[k] = max(0.0, float(value))
    total = sum(out.values())
    if total <= 0:
        raise ValueError("At least one DIKWP weight must be positive")
    return {k: v / total for k, v in out.items()}


@dataclass(slots=True)
class SemanticTrace:
    """A provenance-carrying semantic trace.

    A trace is deliberately not called a concept, fact, claim or definition. It can
    hold an observation, distinction, hypothesis, value tension, purpose fragment,
    question, behavior or relation as supplied by an observer.
    """

    id: str
    text: str
    observer: str
    context: str
    type_weights: Dict[str, float]
    provenance: str
    reliability: float = 0.5
    modality: str = "text"
    scale: str = "unspecified"
    time: str = "present"
    boundary: str = "unspecified"
    affected_parties: List[str] = field(default_factory=list)
    lexical_anchors: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.type_weights = normalize_weights(self.type_weights)
        self.reliability = min(1.0, max(0.0, float(self.reliability)))
        self.affected_parties = [str(x) for x in self.affected_parties]
        self.lexical_anchors = [str(x) for x in self.lexical_anchors]

    @property
    def dominant_type(self) -> DIKWPType:
        return DIKWPType(max(self.type_weights, key=self.type_weights.get))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class IntentPulse:
    """A revisable intent pulse.

    It is not identical to a P node. It is a time- and actor-indexed field that
    biases exploration while remaining revisable by D/I/K/W/P transformations.
    """

    id: str
    actor: str
    desired_change: str
    preserve: List[str]
    avoid: List[str]
    start_traces: List[str]
    goal_traces: List[str]
    horizon: str = "unspecified"
    scale: str = "unspecified"
    reversibility_preference: float = 0.8
    uncertainty_tolerance: float = 0.5
    status: str = "active"
    provenance: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.reversibility_preference = min(1.0, max(0.0, float(self.reversibility_preference)))
        self.uncertainty_tolerance = min(1.0, max(0.0, float(self.uncertainty_tolerance)))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class TransformEvent:
    id: str
    source: str
    target: str
    source_type: DIKWPType
    target_type: DIKWPType
    observer: str
    relation_text: str
    provenance: str
    confidence: float = 0.5
    reversibility: float = 0.5
    affected_parties: List[str] = field(default_factory=list)
    intent_effects: Dict[str, Dict[str, float | str | bool]] = field(default_factory=dict)
    residuals: List[str] = field(default_factory=list)
    meta_rule: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.confidence = min(1.0, max(0.0, float(self.confidence)))
        self.reversibility = min(1.0, max(0.0, float(self.reversibility)))
        self.affected_parties = [str(x) for x in self.affected_parties]
        self.residuals = [str(x) for x in self.residuals]

    @property
    def transform_type(self) -> str:
        return f"{self.source_type.value}->{self.target_type.value}"

    def effect_for(self, intent_id: str) -> Dict[str, float | str | bool]:
        raw = dict(self.intent_effects.get(intent_id, {}))
        return {
            "advance": max(-1.0, min(1.0, float(raw.get("advance", 0.0)))),
            "block": max(0.0, min(1.0, float(raw.get("block", 0.0)))),
            "preserve": max(-1.0, min(1.0, float(raw.get("preserve", 0.0)))),
            "uncertainty": max(0.0, min(1.0, float(raw.get("uncertainty", 0.5)))),
            "power_asymmetry": max(0.0, min(1.0, float(raw.get("power_asymmetry", 0.0)))),
            "revise_intent": bool(raw.get("revise_intent", False)),
            "revision_text": str(raw.get("revision_text", "")),
            "suppresses_residual": bool(raw.get("suppresses_residual", False)),
        }

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["source_type"] = self.source_type.value
        data["target_type"] = self.target_type.value
        data["transform_type"] = self.transform_type
        return data


@dataclass(slots=True)
class InquiryBundle:
    inquiry_id: str
    surface_prompt: str
    anchor_terms: List[str]
    intents: List[IntentPulse]
    traces: List[SemanticTrace]
    transformations: List[TransformEvent]
    observers: List[Dict[str, Any]] = field(default_factory=list)
    boundaries: List[Dict[str, Any]] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        trace_ids = {t.id for t in self.traces}
        if len(trace_ids) != len(self.traces):
            raise ValueError("Duplicate trace ids")
        intent_ids = {i.id for i in self.intents}
        if len(intent_ids) != len(self.intents):
            raise ValueError("Duplicate intent ids")
        for intent in self.intents:
            missing = (set(intent.start_traces) | set(intent.goal_traces)) - trace_ids
            if missing:
                raise ValueError(f"Intent {intent.id} references missing traces: {sorted(missing)}")
        transform_ids = set()
        for event in self.transformations:
            if event.id in transform_ids:
                raise ValueError(f"Duplicate transform id: {event.id}")
            transform_ids.add(event.id)
            if event.source not in trace_ids or event.target not in trace_ids:
                raise ValueError(f"Transform {event.id} has unknown endpoint")
            unknown_intents = set(event.intent_effects) - intent_ids
            if unknown_intents:
                raise ValueError(f"Transform {event.id} references unknown intents: {sorted(unknown_intents)}")
        forbidden = {"concept", "definition", "concept_registry", "final_label"}
        if forbidden & set(self.metadata):
            raise ValueError("Inquiry metadata contains concept-locking fields")

    def trace_map(self) -> Dict[str, SemanticTrace]:
        return {t.id: t for t in self.traces}

    def intent_map(self) -> Dict[str, IntentPulse]:
        return {i.id: i for i in self.intents}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "inquiry_id": self.inquiry_id,
            "surface_prompt": self.surface_prompt,
            "anchor_terms": self.anchor_terms,
            "intents": [x.to_dict() for x in self.intents],
            "traces": [x.to_dict() for x in self.traces],
            "transformations": [x.to_dict() for x in self.transformations],
            "observers": self.observers,
            "boundaries": self.boundaries,
            "metadata": self.metadata,
        }


@dataclass(slots=True)
class TrajectoryVector:
    evidence_floor: float
    intent_advance: float
    reversibility_floor: float
    observer_diversity: float
    residual_preservation: float
    transformation_diversity: float
    power_symmetry: float
    uncertainty_fit: float

    def dominates(self, other: "TrajectoryVector") -> bool:
        a = self.to_dict()
        b = other.to_dict()
        ge = all(float(a[k]) >= float(b[k]) for k in a)
        gt = any(float(a[k]) > float(b[k]) for k in a)
        return ge and gt

    def to_dict(self) -> Dict[str, float]:
        return {k: round(float(v), 6) for k, v in asdict(self).items()}


@dataclass(slots=True)
class SemanticTrajectory:
    id: str
    intent_id: str
    trace_path: List[str]
    transform_path: List[str]
    vector: TrajectoryVector
    revises_intent: bool = False
    revision_texts: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "intent_id": self.intent_id,
            "trace_path": self.trace_path,
            "transform_path": self.transform_path,
            "vector": self.vector.to_dict(),
            "revises_intent": self.revises_intent,
            "revision_texts": self.revision_texts,
        }
